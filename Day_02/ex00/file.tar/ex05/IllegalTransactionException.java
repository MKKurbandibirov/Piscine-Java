package ex05;

public class IllegalTransactionException extends Exception {
	public IllegalTransactionException(String message) {
		super(message);
	}
}
