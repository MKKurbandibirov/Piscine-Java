package ex05;

public class UserNotFoundException extends Exception {
	public UserNotFoundException(String message) {
		super(message);
	}	
}
